# Current Skills

- Adds a primary 6 round revolver for Bandit 
- Adds a high power 1 round blunderbuss for Bandit