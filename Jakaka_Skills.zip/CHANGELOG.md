**1.0.3 Changes:**

* Added Changelog (Hi :3)

**1.0.2 Changes:**

* Added Blunderbuss
* Fixed Slayer Audio
* Fixed Slayer Animation 

**1.0.1 Changes:**

* Minor code changes

**1.0.0 Changes:**

* First release